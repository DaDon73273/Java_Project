package expleo;

import java.util.InputMismatchException;
import java.util.Scanner;

public class DelimeterTest {

	static String input = "range Be Still";

	static Scanner scanner = new Scanner(input).useDelimiter(" ");
	static Scanner in=new Scanner(System.in);

	public static void main(String[] args) {
		String cmd = scanner.next();
			
			try {

				if (cmd.equals("even")) {
					int para1 = scanner.nextInt();
					if (para1 % 2 != 0) {
						System.out.println("No");
					} else {
						System.out.println("Yes");
					}
				} else if (cmd.equals("odd")) {
					int para1 = scanner.nextInt();
					if (para1 % 2 != 0) {
						System.out.println("Yes");
					} else {
						System.out.println("No");
					}
				} else if (cmd.equals("square")) {
					int para1 = scanner.nextInt();
					System.out.println(Math.sqrt(para1));
				} else if (cmd.equals("show")) {
					String para1 = scanner.next();
					System.out.println(para1);
				} else if (cmd.equals("concat")) {
					String para1 = scanner.next();
					String para2 = scanner.next();
					System.out.println(para1 + para2);
				} else if (cmd.equals("range")) {
					int para1 = scanner.nextInt();
					int para2 = scanner.nextInt();
					for (int x = para1; x <= para2; x++) {
						System.out.print(x + " ");
					}
				} else if(cmd.equals("quit")){
					scanner.close();
					
				//	in.close();
				}else {
					System.out.println("ERROR: Please enter valid input");
				}
			} catch (InputMismatchException e) {
				System.out.println("ERROR: Invalid input");
			}
		
	}
}
